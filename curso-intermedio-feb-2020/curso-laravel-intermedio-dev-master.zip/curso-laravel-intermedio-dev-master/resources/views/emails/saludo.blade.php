@component('mail::message')
# Saludo

Este es un correo de prueba para saludar

Gracias,<br>
{{ config('app.name') }}
@endcomponent
