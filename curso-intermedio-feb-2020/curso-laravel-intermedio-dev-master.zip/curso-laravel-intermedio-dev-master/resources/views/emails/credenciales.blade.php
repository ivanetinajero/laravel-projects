<!DOCTYPE html>
<html lang="es">
	<head>
		<meta charset="UTF-8">
		<title>Credenciales</title>
	</head>
	<body>
		<strong>Correo: </strong>{{ $email }}
		<br>
		<strong>Contraseña: </strong>{{ $password }}
	</body>
</html>
